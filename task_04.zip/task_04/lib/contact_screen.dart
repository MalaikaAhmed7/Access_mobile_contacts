import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:contacts_service/contacts_service.dart';

class ContactsListScreen extends StatefulWidget {
  @override
  _ContactsListScreenState createState() => _ContactsListScreenState();
}

class _ContactsListScreenState extends State<ContactsListScreen> {
  List<Contact> _contacts = [];
  List<Contact> _filteredContacts = [];
  bool _loading = false;
  bool _permissionGranted = false;

  @override
  void initState() {
    super.initState();
    _checkPermission();
  }

  Future<void> _checkPermission() async {
    setState(() {
      _loading = true;
    });

    PermissionStatus permissionStatus = await Permission.contacts.status;

    if (!permissionStatus.isGranted) {
      permissionStatus = await Permission.contacts.request();
    }

    if (permissionStatus.isGranted) {
      setState(() {
        _permissionGranted = true;
      });
      _loadContacts();
    } else {
      setState(() {
        _permissionGranted = false;
      });
    }

    setState(() {
      _loading = false;
    });
  }

  // Load contacts after permission is granted
  Future<void> _loadContacts() async {
    try {
      Iterable<Contact> contacts = await ContactsService.getContacts();
      setState(() {
        _contacts = contacts.toList();
        _filteredContacts = _contacts;
      });
    } catch (e) {
      print("Error loading contacts: $e");
    }
  }

  // Filter contacts based on search
  void _filterContacts(String query) {
    final filtered = _contacts.where((contact) {
      final name = contact.displayName ?? '';
      return name.toLowerCase().contains(query.toLowerCase());
    }).toList();

    setState(() {
      _filteredContacts = filtered;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contacts'),
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator())
          : _permissionGranted
              ? Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextField(
                        decoration: InputDecoration(
                          labelText: 'Search Contacts',
                          prefixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                        ),
                        onChanged: _filterContacts,
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _filteredContacts.length,
                        itemBuilder: (context, index) {
                          final contact = _filteredContacts[index];
                          
                          // Safely access the first phone number if it exists
                          final phoneNumber = (contact.phones != null && contact.phones!.isNotEmpty)
                              ? contact.phones!.first.value
                              : 'No Phone Number';

                          return ListTile(
                            title: Text(contact.displayName ?? 'No Name'),
                            subtitle: Text(phoneNumber ?? 'No Phone Number'),
                            leading: CircleAvatar(
                              child: Text(
                                contact.initials(),
                                style: TextStyle(color: Colors.white),
                              ),
                              backgroundColor: Theme.of(context).primaryColor,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                )
              : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error, color: Colors.red, size: 80),
                      SizedBox(height: 20),
                      Text(
                        'Contacts permission is required to display contacts.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 18),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _checkPermission,
                        child: Text('Allow Permission'),
                      ),
                    ],
                  ),
                ),
    );
  }
}
