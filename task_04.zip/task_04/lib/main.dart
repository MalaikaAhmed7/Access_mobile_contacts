import 'package:flutter/material.dart';
import 'contact_screen.dart'; // Importing the screen where contacts will be listed

void main() {
  runApp(MyApp()); // Running the app
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contacts App', 
      theme: ThemeData(
        primarySwatch: Colors.blue, 
      ),
      home: ContactsListScreen(), // Home screen of the app displaying the contacts list
    );
  }
}
