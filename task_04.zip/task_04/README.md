
# Task 04 - Contacts App with Permission Handling:

    This Flutter project demonstrates a contacts app where the user can view and search their contacts. The app requests the necessary permissions to access contacts using the permission_handler package. It loads contacts using the contacts_service package and allows searching through the list of contacts.

# Features:

    Requests contacts permission on app startup.
    Displays a list of contacts with name and phone number.
    Search functionality to filter contacts.

# Getting Started:

    To run the project, follow these steps:
        - Clone this repository.
        - Install dependencies by running flutter pub get.
        - Run the app using flutter run.

# Resources:

   - Flutter Official Documentation
   - Contacts Service Plugin
   - Permission Handler Plugin